package com.lt.service;

public interface ProfessorService {

	public void addGrades();

	public void viewRegisteredStudents();

	public void selectCourses();
	
	public void professorMenu();
}
