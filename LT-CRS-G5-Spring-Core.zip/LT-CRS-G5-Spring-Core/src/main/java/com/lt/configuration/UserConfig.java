/**
 * 
 */
package com.lt.configuration;

/**
 * @author user211
 *
 */
public class UserConfig {

}
