package com.lt.service.impl;

import com.lt.service.NotificationService;

public class NotificationServiceImpl implements NotificationService {

}
