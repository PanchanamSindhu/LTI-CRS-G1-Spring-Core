package com.lt.service;

public interface CourseService {

	public void CoursesList();

	public Void AllCoursesList();
}
