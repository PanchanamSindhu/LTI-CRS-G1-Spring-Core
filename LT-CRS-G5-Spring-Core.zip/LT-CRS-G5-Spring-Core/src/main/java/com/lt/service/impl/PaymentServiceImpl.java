package com.lt.service.impl;

import com.lt.service.PaymentService;

public class PaymentServiceImpl implements PaymentService {

	@Override
	public String sendNotification() {
		// TODO Auto-generated method stub
		return null;
	}

}
