package com.lt.exception;

public class StudentNotFoundException extends RuntimeException {

}
