package com.lt.exception;

public class UserNotFoundException extends RuntimeException {

}
