package com.lt.service;

public interface ReportCardService {

	public void calculateCgpa();
}
