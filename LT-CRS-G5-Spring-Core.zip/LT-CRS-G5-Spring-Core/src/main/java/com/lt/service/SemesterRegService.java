package com.lt.service;

public interface SemesterRegService {

	public void addCourse();

	public void dropCourse();

	public void payCourseFee();

	public void viewRegisteredCourses();
}
