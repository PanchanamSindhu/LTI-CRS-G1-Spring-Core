package com.lt.service;

public interface UserService {

	public void userLogin();

	public void registerUser();

	public void resetPassword();

	public void updateDetails();
}
