package com.lt.service;

public interface PaymentService {

	public String sendNotification();
}
