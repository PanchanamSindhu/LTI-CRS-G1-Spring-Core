package com.lt.service.impl;

import com.lt.service.SemesterRegService;

public class SemesterRegServiceImpl implements SemesterRegService {

	@Override
	public void addCourse() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dropCourse() {
		// TODO Auto-generated method stub

	}

	@Override
	public void payCourseFee() {
		// TODO Auto-generated method stub

	}

	@Override
	public void viewRegisteredCourses() {
		// TODO Auto-generated method stub

	}

}
