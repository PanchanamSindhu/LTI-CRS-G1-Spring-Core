package com.lt.service;

public interface NotificationService {

}
