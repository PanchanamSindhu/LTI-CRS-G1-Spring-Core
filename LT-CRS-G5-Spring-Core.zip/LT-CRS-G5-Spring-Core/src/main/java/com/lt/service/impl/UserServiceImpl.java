package com.lt.service.impl;

import org.springframework.stereotype.Service;

import com.lt.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Override
	public void userLogin() {
		// TODO Auto-generated method stub

	}

	@Override
	public void registerUser() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resetPassword() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateDetails() {
		// TODO Auto-generated method stub

	}

}
