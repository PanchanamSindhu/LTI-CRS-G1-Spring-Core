package com.lt.service.impl;

import com.lt.service.ReportCardService;

public class ReportCardServiceImpl implements ReportCardService {

	@Override
	public void calculateCgpa() {
		// TODO Auto-generated method stub

	}

}
