package com.lt.dao;

import java.util.List;

public interface CourseDaoInterface {
	
	public List<String> ListOfCourses();

	public List<String> returnAllCoursesList();

}
